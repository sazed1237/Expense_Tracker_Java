/*
 * Project: Expense Tracker
 * Language: Java
 * Description: A simple Java application to track and categorize personal expenses.
 * Features:
 * - Add/Update/Delete Expenses
 * - Categorize Expenses
 * - View Monthly Summary
 * - Export Data to a File
 */

import java.util.*;
import java.io.*;

public class Main {

    private static final List<Expense> expenses = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        while (true) {
            System.out.println("\nExpense Tracker Menu:");
            System.out.println("1. Add Expense");
            System.out.println("2. View Expenses");
            System.out.println("3. Delete Expense");
            System.out.println("4. View Monthly Summary");
            System.out.println("5. Export to File");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addExpense(scanner);
                    break;
                case 2:
                    viewExpenses();
                    break;
                case 3:
                    deleteExpense(scanner);
                    break;
                case 4:
                    viewMonthlySummary();
                    break;
                case 5:
                    exportToFile();
                    break;
                case 6:
                    System.out.println("Exiting Expense Tracker. Goodbye!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addExpense(Scanner scanner) {
        System.out.print("Enter expense name: ");
        String name = scanner.nextLine();

        System.out.print("Enter category (e.g., Food, Transport, Rent): ");
        String category = scanner.nextLine();

        System.out.print("Enter amount: ");
        double amount = scanner.nextDouble();

        System.out.print("Enter date (YYYY-MM-DD): ");
        scanner.nextLine(); // Consume newline
        String date = scanner.nextLine();

        expenses.add(new Expense(name, category, amount, date));
        System.out.println("Expense added successfully.");
    }

    private static void viewExpenses() {
        if (expenses.isEmpty()) {
            System.out.println("No expenses recorded.");
            return;
        }

        System.out.println("\nExpenses:");
        for (int i = 0; i < expenses.size(); i++) {
            System.out.println((i + 1) + ". " + expenses.get(i));
        }
    }

    private static void deleteExpense(Scanner scanner) {
        viewExpenses();

        if (expenses.isEmpty()) {
            return;
        }

        System.out.print("Enter the number of the expense to delete: ");
        int index = scanner.nextInt();

        if (index > 0 && index <= expenses.size()) {
            expenses.remove(index - 1);
            System.out.println("Expense deleted successfully.");
        } else {
            System.out.println("Invalid expense number.");
        }
    }

    private static void viewMonthlySummary() {
        if (expenses.isEmpty()) {
            System.out.println("No expenses recorded.");
            return;
        }

        Map<String, Double> categoryTotals = new HashMap<>();
        for (Expense expense : expenses) {
            categoryTotals.put(expense.getCategory(), categoryTotals.getOrDefault(expense.getCategory(), 0.0) + expense.getAmount());
        }

        System.out.println("\nMonthly Summary:");
        for (Map.Entry<String, Double> entry : categoryTotals.entrySet()) {
            System.out.printf("%s: %.2f\n", entry.getKey(), entry.getValue());
        }
    }

    private static void exportToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("expenses.txt"))) {
            for (Expense expense : expenses) {
                writer.write(expense.toString());
                writer.newLine();
            }
            System.out.println("Expenses exported to expenses.txt.");
        } catch (IOException e) {
            System.out.println("Error exporting to file: " + e.getMessage());
        }
    }
}

class Expense {
    private final String name;
    private final String category;
    private final double amount;
    private final String date;

    public Expense(String name, String category, double amount, String date) {
        this.name = name;
        this.category = category;
        this.amount = amount;
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return String.format("Name: %s, Category: %s, Amount: %.2f, Date: %s", name, category, amount, date);
    }
}
